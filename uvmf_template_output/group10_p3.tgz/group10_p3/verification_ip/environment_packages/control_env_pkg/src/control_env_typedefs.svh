//----------------------------------------------------------------------
// Created with uvmf_gen version 2023.4_2
//----------------------------------------------------------------------
// pragma uvmf custom header begin
// pragma uvmf custom header end
//----------------------------------------------------------------------
//----------------------------------------------------------------------
//     
// DESCRIPTION: 
// This file contains defines and typedefs to be compiled for use in
// the environment package.
//
//----------------------------------------------------------------------
//----------------------------------------------------------------------
//


  // pragma uvmf custom additional begin
  // pragma uvmf custom additional end

