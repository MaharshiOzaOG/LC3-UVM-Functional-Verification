//----------------------------------------------------------------------
// Created with uvmf_gen version 2023.4_2
//----------------------------------------------------------------------
// pragma uvmf custom header begin
// pragma uvmf custom header end
//----------------------------------------------------------------------
//----------------------------------------------------------------------
//     
// DESCRIPTION: This interface contains the control_out interface signals.
//      It is instantiated once per control_out bus.  Bus Functional Models, 
//      BFM's named control_out_driver_bfm, are used to drive signals on the bus.
//      BFM's named control_out_monitor_bfm are used to monitor signals on the 
//      bus. This interface signal bundle is passed in the port list of
//      the BFM in order to give the BFM access to the signals in this
//      interface.
//
//----------------------------------------------------------------------
//----------------------------------------------------------------------
//
// This template can be used to connect a DUT to these signals
//
// .dut_signal_port(control_out_bus.enable_updatePC), // Agent input 
// .dut_signal_port(control_out_bus.enable_fetch), // Agent input 
// .dut_signal_port(control_out_bus.enable_decode), // Agent input 
// .dut_signal_port(control_out_bus.enable_execute), // Agent input 
// .dut_signal_port(control_out_bus.enable_writeback), // Agent input 
// .dut_signal_port(control_out_bus.br_taken), // Agent input 
// .dut_signal_port(control_out_bus.bypass_alu_1), // Agent input 
// .dut_signal_port(control_out_bus.bypass_alu_2), // Agent input 
// .dut_signal_port(control_out_bus.bypass_mem_1), // Agent input 
// .dut_signal_port(control_out_bus.bypass_mem_2), // Agent input 
// .dut_signal_port(control_out_bus.mem_state), // Agent input 

import uvmf_base_pkg_hdl::*;
import control_out_pkg_hdl::*;

interface  control_out_if 

  (
  input tri clk, 
  input tri rst,
  inout tri  enable_updatePC,
  inout tri  enable_fetch,
  inout tri  enable_decode,
  inout tri  enable_execute,
  inout tri  enable_writeback,
  inout tri  br_taken,
  inout tri  bypass_alu_1,
  inout tri  bypass_alu_2,
  inout tri  bypass_mem_1,
  inout tri  bypass_mem_2,
  inout tri [1:0] mem_state
  );

modport monitor_port 
  (
  input clk,
  input rst,
  input enable_updatePC,
  input enable_fetch,
  input enable_decode,
  input enable_execute,
  input enable_writeback,
  input br_taken,
  input bypass_alu_1,
  input bypass_alu_2,
  input bypass_mem_1,
  input bypass_mem_2,
  input mem_state
  );

modport initiator_port 
  (
  input clk,
  input rst,
  input enable_updatePC,
  input enable_fetch,
  input enable_decode,
  input enable_execute,
  input enable_writeback,
  input br_taken,
  input bypass_alu_1,
  input bypass_alu_2,
  input bypass_mem_1,
  input bypass_mem_2,
  input mem_state
  );

modport responder_port 
  (
  input clk,
  input rst,  
  output enable_updatePC,
  output enable_fetch,
  output enable_decode,
  output enable_execute,
  output enable_writeback,
  output br_taken,
  output bypass_alu_1,
  output bypass_alu_2,
  output bypass_mem_1,
  output bypass_mem_2,
  output mem_state
  );
  

// pragma uvmf custom interface_item_additional begin
// pragma uvmf custom interface_item_additional end

endinterface

// pragma uvmf custom external begin
// pragma uvmf custom external end

